//
//  HotelListTableViewCell.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 11/5/2023.
//

import Foundation

import UIKit

class HotelListTableViewCell: UITableViewCell {
    var hotelId : String?
    
    @IBOutlet weak var hotelImageView: UIImageView!
    @IBOutlet weak var hotelIdLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
}
