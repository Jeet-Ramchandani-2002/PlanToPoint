//
//  HotelDetailViewController.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 11/5/2023.
//

import Foundation
import UIKit

class HotelDetailViewController: UIViewController {
    
    var searchData : [String: String]?
    
    @IBOutlet weak var titleLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    func getHotelDetails(){
        if let id = searchData["hotelId"] , let checkIndate = searchData["checkIn"] , let checkOutDate = searchData["checkOut"]
    }
    
}
