//
//  Model.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 10/5/2023.
//

import Foundation
struct Hotel: Codable { // using coadable only we can decode the jason file
    var address: Address?
    var chainCode: String?
    var dupeId: Int?
    var geoCode: GeoCode?
    var hotelId: String?
    var iataCode: String?
    var lastUpdate: String?
    var name: String?
}

struct Address: Codable {
    var countryCode: String?
}

struct GeoCode: Codable {
    var latitude: Double?
    var longitude: Double?
}
struct Details: Codable {
    var type: String?
    var hotel: HotelDetail?
    var available: Bool?
    var offers: [Offer]?
    var datumSelf: String?
}

struct HotelDetail: Codable {
    var type, hotelID, chainCode, dupeID: String?
    var name, cityCode: String?
    var latitude, longitude: Double?
}

struct Offer: Codable {
    var id, checkInDate, checkOutDate, rateCode: String?
    var rateFamilyEstimated: RateFamilyEstimated?
    var room: Room?
    var guests: Guests?
    var price: Price?
    var policies: Policies?
    var offerSelf: String?
}

struct Guests: Codable {
    var adults: Int?
}

struct Policies: Codable {
    var cancellations: [Cancellation]?
    var paymentType: String?
}
struct Cancellation: Codable {
    var description: CancellationDescription?
    var type: String?
}

// MARK: - CancellationDescription
struct CancellationDescription: Codable {
    var text: String?
}

// MARK: - Price
struct Price: Codable {
    var currency, base, total: String?
    var variations: Variations?
}

// MARK: - Variations
struct Variations: Codable {
    var average: Average?
    var changes: [Change]?
}

// MARK: - Average
struct Average: Codable {
    var base: String?
}

// MARK: - Change
struct Change: Codable {
    var startDate, endDate, base: String?
}

// MARK: - RateFamilyEstimated
struct RateFamilyEstimated: Codable {
    var code, type: String?
}

// MARK: - Room
struct Room: Codable {
    var type: String?
    var typeEstimated: TypeEstimated?
    var description: RoomDescription?
}

// MARK: - RoomDescription
struct RoomDescription: Codable {
    var text, lang: String?
}

// MARK: - TypeEstimated
struct TypeEstimated: Codable {
    var category: String?
    var beds: Int?
    var bedType: String?
}
