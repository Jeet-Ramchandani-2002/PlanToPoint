//
//  NetworkHelper.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 8/5/2023.
//

import Foundation
import UIKit

class NetworkHelper { //to call api , figuring any api call
    
    
    func getToken() {  //https://developers.amadeus.com/self-service/apis-docs/guides/authorization-262
        if let url = URL(string: "https://test.api.amadeus.com/v1/security/oauth2/token") {  // url object is created , web address is a  string so we need to create an url object
            var request = URLRequest(url: url)  // a url request is created
            request.httpMethod = "POST" // get - read / post - send the data to server/ put - sending the data to server and updating it / delete
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField:"Content-Type"); // header of request , // header is an attriute for request / for backend to get the content of it
            let data : Data = "client_id=UB97y9nJ09vnY1G4UySHCNKiEvBJYksF&client_secret=QzkJuoAI06HYW9ej&grant_type=client_credentials".data(using: .utf8)! // sending client id , client_secret , grant_id
            request.httpBody = data
            let task = URLSession.shared.dataTask(with: request) { data, Response, error in  //task created in a session URLSession.shared- object of url session // data task - function to create a task
                if let data = data { // data in bytes , cannot be used
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                            print(json)
                            DispatchQueue.main.async { // switching from background to main thread in the process state
                                (UIApplication.shared.delegate as? AppDelegate)?.access_token = "\(json["token_type"]!) \(json["access_token"]!)"
                            } // get the object of app delegate and access of the variable
                        }// app delegate - memeber of ui application
                    } catch {
                        
                    }
                }
            }
            task.resume()
        }
    }
    
    func getHotel(cityCode: String, completion: @escaping (Result<[Hotel]?, Error>) -> Void) {  // closure - it is a block which can be passed so it in function , escaping - can be executed in later point of time
        // https://test.api.amadeus.com/v1/reference-data/locations/hotels/by-city?cityCode=PAR
        var path = "https://test.api.amadeus.com/v1/reference-data/locations/hotels/by-city?cityCode="
        path.append(cityCode)
        if let url = URL(string: path), let token = (UIApplication.shared.delegate as? AppDelegate)?.access_token {
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.setValue(token, forHTTPHeaderField:"Authorization");
            let task = URLSession.shared.dataTask(with: request) { data, Response, error in
                if let error = error {
                    completion(.failure(error))
                } else {
                    if let data = data,
                       let json = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]), // metadata and hotel data
                       let hotelJson = json["data"], // we get hoteldata
                       let hotelData = try? JSONSerialization.data(withJSONObject: hotelJson), // hoteldata
                       let parsedObj = try? JSONDecoder().decode([Hotel].self, from: hotelData) {
                        print(json)
                        print(parsedObj)
                        completion(.success(parsedObj))
                    }
                }
            }
            task.resume()
        }
    }
    
    func getHotel(by id: String, adults: String, chekinDate: String, checkOutDate: String, roomQuantity: String, completion: @escaping (Result<Details, Error>) -> Void) {
        var path = "https://test.api.amadeus.com/v3/shopping/hotel-offers?"
        //ALATL849&adults=1&checkInDate=2023-11-22&roomQuantity=1&paymentPolicy=NONE&bestRateOnly=true" // part of the url
        
        if let url = URL(string: path), let token = (UIApplication.shared.delegate as? AppDelegate)?.access_token {
            var url = url
            let queryItems = [URLQueryItem(name: "hotelIds", value: id),
                              URLQueryItem(name: "adults", value: "1"),
                              URLQueryItem(name: "checkInDate", value: "2023-11-22"),
                              URLQueryItem(name: "checkOutDate", value: "2023-11-23"),
                              URLQueryItem(name: "roomQuantity", value: "1")]
            url.append(queryItems: queryItems)
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.setValue(token, forHTTPHeaderField:"Authorization");
            let task = URLSession.shared.dataTask(with: request) { data, Response, error in
                if let error = error {
                    completion(.failure(error))
                } else {
                    if let data = data,
                       let json = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]),
                       let hotelJson = json["data"],
                       let hotelData = try? JSONSerialization.data(withJSONObject: hotelJson),
                       let parsedObj = try? JSONDecoder().decode([Details].self, from: hotelData) {
                        print(json)
                        print(parsedObj.first)
                        completion(.success(parsedObj.first!))
                    }
                }
            }
            task.resume()
        }
    }
}

