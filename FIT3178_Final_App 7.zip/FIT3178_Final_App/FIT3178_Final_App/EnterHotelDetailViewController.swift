//
//  EnterHotelDetailViewController.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 9/5/2023.
//

import UIKit

enum SelectedField: String{
    case city
    case room
    case passenger
    case none
}

class EnterHotelDetailViewController: UIViewController , UIPickerViewDelegate ,UIPickerViewDataSource {
    var cityCode: String = ""
    let cityData:[(name: String, code: String)] = [("Amsterdam, Netherlands", "AMS"), ("Atlanta, USA", "ATL"), ("Bangkok, Thailand", "BKK"), ("Barcelona, Spain", "BCN"), ("Beijing, China", "PEK"), ("Chicago, USA", "ORD"), ("Dallas, USA", "DFW"), ("Delhi, India", "DEL"), ("Denver, USA", "DEN"), ("Dubai, UAE", "DXB"), ("Frankfurt, Germany", "FRA"), ("Guangzhou, China", "CAN"), ("Hong Kong", "HKG"), ("Jakarta, Indonesia", "CGK"), ("Kuala Lumpur, Malaysia", "KUL"), ("Las Vegas, USA", "LAS"), ("London, UK", "LHR"), ("Los Angeles, USA", "LAX"), ("Madrid, Spain", "MAD"), ("Miami, USA", "MIA"), ("Munich, Germany", "MUC"), ("New York, USA", "JFK"), ("Paris, France", "CDG"), ("Seattle, USA", "SEA"), ("Seoul, South Korea", "ICN"), ("Shanghai, China", "PVG"), ("Singapore", "SIN"), ("Sydney, Australia", "SYD"), ("Tokyo, Japan", "HND"), ("Toronto, Canada", "YYZ"), ("San Francisco, USA", "SFO")]
    
    var checkInDate: String = ""
    var checkOutDate: String = ""
    var selectedField = SelectedField.none
    var numberofRoom = "1"
    var numberofPassenger = "1"
    var selectedCityName = ""
    var selectedValue = ""

    @IBOutlet weak var pickerOverlayView: UIView!
    @IBOutlet weak var checkOutDatePicker: UIDatePicker!
    @IBOutlet weak var checkInDatePicker: UIDatePicker!
    @IBOutlet weak var passengerButton: UIButton!
    @IBOutlet weak var roomButton: UIButton!
    
    @IBOutlet weak var pickerField: UIPickerView!
    @IBOutlet weak var destinationTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Search hotels"
        pickerOverlayView.isHidden = true
        
        destinationTextField.delegate = self
        
        self.pickerField.delegate = self // setting up the delegate for picker view
                self.pickerView(pickerField, didSelectRow: 0, inComponent: 0)
               
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func checkOutDateAction(_ sender: UIDatePicker) {
        let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd"
                checkOutDate = formatter.string(from: sender.date)
    }
    @IBAction func searchHotelAction(_ sender: Any) {
        if pickerOverlayView.isHidden == false {
            return // once tap then only next screen
        }
        let searchData = ["destination" : cityCode ,"checkIn" : checkInDate , "checkOut" : checkOutDate , "room" : numberofRoom , "passenger" : numberofPassenger ]
        performSegue(withIdentifier: "displayHotels", sender: searchData)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let hotelListVC = segue.destination as? SearchHotelsTableViewController
        hotelListVC?.searchData = sender as? [String:String]
    }
    
    @IBAction func numberofPassengerAction(_ sender: Any) {
        selectedField = .passenger
        pickerField.reloadAllComponents()
        pickerOverlayView.isHidden = false
        
    }
    
    @IBAction func numberofRoomAction(_ sender: Any) {
        selectedField = .room
        pickerField.reloadAllComponents()
        pickerOverlayView.isHidden = false
    }
    
     @IBAction func checkInDatePicker(_ sender: UIDatePicker) {
         let formatter = DateFormatter()
                 formatter.dateFormat = "yyyy-MM-dd"
                 checkInDate = formatter.string(from: sender.date)
                 checkOutDate  = formatter.string(from: sender.date.advanced(by: 60*60*24)) // Automatically set the check-out date to the next day (Number of seconds in 1 day)
     }
    
    @IBAction func doneButtonAction(_ sender: Any) {
        switch selectedField {
        case .city:
            cityCode = selectedValue.isEmpty ? cityCode : selectedValue
            destinationTextField.text = selectedCityName
        case .room:
            numberofRoom = selectedValue.isEmpty ?  numberofRoom : selectedValue
            roomButton.setTitle(numberofRoom, for: .normal)
        case.passenger:
            numberofPassenger = selectedValue.isEmpty ? numberofPassenger : selectedValue
            passengerButton.setTitle(numberofPassenger, for: .normal)
        case .none:
            print("Do nothing")
        }
        selectedField = .none
        selectedValue = "" // once it is been set we dont want to retain here
        pickerOverlayView.isHidden =  true
    }
    /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension EnterHotelDetailViewController {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 // number of column to diplay data
    }
   
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {      //number of rows in component
        switch selectedField{
        case .city:
            return cityData.count
            
        case .room:
            return 9
        case .passenger:
            return 9
        case .none:
            return 0
        }
        
    }
   
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {   // whichever is highlighted will be identified here
        switch selectedField{
        case .city:
            selectedCityName = cityData[row].name
            selectedValue = cityData[row].code
            
        case .room:
            selectedValue = "\(row + 1)"
        case .passenger:
            selectedValue = "\(row + 1)"
        case .none:
            print("Do nothing")
        }
       
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {   // what data we want to display
        switch selectedField{
        case .city:
            return cityData[row].name // only displaying name
            
        case .room:
            return "\(row + 1)"
        case .passenger:
            return "\(row + 1)"
        case .none:
            return ""
        }
        
    }
}

extension EnterHotelDetailViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
        selectedField = .city
        pickerField.reloadAllComponents()
        pickerOverlayView.isHidden = false
        
    }
}
