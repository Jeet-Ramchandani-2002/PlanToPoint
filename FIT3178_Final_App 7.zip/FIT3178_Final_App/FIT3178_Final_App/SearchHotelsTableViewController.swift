//
//  SearchHotelsTableViewController.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 9/5/2023.
//

import UIKit

class SearchHotelsTableViewController: UITableViewController{

    @IBOutlet var hotelListTabelView: UITableView!
    var searchData : [String: String]? // intialize empty dictionary
    var hotelList : [Hotel]? // data recieving from api
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hotelListTabelView.delegate = self
        hotelListTabelView.dataSource = self
        getHotel()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    func getHotel(){
        if let cityCode = searchData?["destination"]{
            NetworkHelper().getHotel(cityCode: cityCode) { result in
                switch result {
                case .success(let response):
                    print(response)
                    self.hotelList = response
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                case .failure(let error):
                    print(error.localizedDescription)
                }
            }
        }
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return hotelList?.count ?? 0
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 260
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {// creation of cell
       guard  let cell = tableView.dequeueReusableCell(withIdentifier: "hotelCell", for: indexPath) as? HotelListTableViewCell else {
           return UITableViewCell()
       }
        let hotelData = hotelList?[indexPath.row] // indexpath - combination of section and row - position of the cell
        cell.titleLabel.text = hotelData?.name
        cell.hotelIdLabel.text = hotelData?.hotelId
        cell.hotelId = hotelData?.hotelId

         

        return cell
    }
   
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as? HotelListTableViewCell
        if let id = cell?.hotelId {
            searchData?.updateValue(id , forKey: "hotelID")
            performSegue(withIdentifier: "displayInfo", sender: searchData)
        }
    }
  
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let hotelDetailVC = segue.destination as? HotelDetailViewController
        hotelDetailVC?.searchData = sender as? [String: String]
    }
   

}
