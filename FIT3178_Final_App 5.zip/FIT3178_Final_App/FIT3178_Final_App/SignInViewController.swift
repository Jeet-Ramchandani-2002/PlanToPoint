//
//  SignInViewController.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 3/5/2023.
//

import UIKit
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore

class SignInViewController: UIViewController {

    @IBOutlet weak var logInOutlet: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    var activityIndicatorView = UIActivityIndicatorView(style: .large)
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

 
    
    @IBAction func logInButtonAction(_ sender: Any) {
        
        if let email = emailTextField.text , isValidEmail(text: email) , let password = passwordTextField.text , password.count >= 6 {
            
            logInOutlet.isUserInteractionEnabled = false
            showIndicator(activityIndicatorView: activityIndicatorView)
            Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
                self.logInOutlet.isUserInteractionEnabled = true
                self.hideIndicator(activityIndicatorView: self.activityIndicatorView)
                if error != nil{
                    self.displayAlert(message: "The detail is not stored")
                    
                }else{
                    self.performSegue(withIdentifier: "dashboard", sender: nil)
                }
            }
        }
        else{
            displayAlert(message: "Enter Valid username  / password")
        }
    }
    func isValidEmail(text: String) -> Bool {
        
        let regex = try? NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
        let result = regex?.firstMatch(in: text, range: NSMakeRange(0, text.count))             // nsmakerange : from bigning to end
        
        
        return result != nil
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
