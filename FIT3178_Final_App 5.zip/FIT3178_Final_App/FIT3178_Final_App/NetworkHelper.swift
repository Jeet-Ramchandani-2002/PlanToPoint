//
//  NetworkHelper.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 8/5/2023.
//

import Foundation
import Amadeus
import UIKit

class NetworkHelper {
    
    var hotelBaseURL = "test.api.amadeus.com/v3/shopping/hotel-offers"
    
    
    
    
    func getHotels(){
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate  { // to get the instance of amadeus
            appDelegate.amadeus.shopping.hotelOffers.get(params: ["cityCode" : "PAR"
                                                                  ]) { result in
                switch result{
                case .success(let data):
                    print(data)
                case .failure(let error):
                    print(error)
                }
                
            }
        }
    }
    
}
