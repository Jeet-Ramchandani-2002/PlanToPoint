//
//  EnterHotelDetailViewController.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 9/5/2023.
//

import UIKit

class EnterHotelDetailViewController: UIViewController {

    @IBOutlet weak var pickerField: UIPickerView!
    @IBOutlet weak var destinationTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Search hotels"
        NetworkHelper().getHotels()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func checkOutDateAction(_ sender: Any) {
    }
    @IBAction func searchHotelAction(_ sender: Any) {
    }
    @IBAction func numberofPassengerAction(_ sender: Any) {
    }
    
    @IBAction func numberofRoomAction(_ sender: Any) {
    }
    
     @IBAction func checkInDatePicker(_ sender: Any) {
     }
    
    /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
