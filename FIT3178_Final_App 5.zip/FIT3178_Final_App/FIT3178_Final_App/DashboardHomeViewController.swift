//
//  dashboardHomeViewController.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 5/5/2023.
//

import UIKit

enum BookingType : String {
    case Flight
    case Hotel
    case Activity
}

class dashboardHomeViewController: UIViewController {

    var selectedType = BookingType.Flight
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func segmentControlAction(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            selectedType = .Flight
        case 1:
            selectedType = .Hotel
        case 2:
            selectedType = .Activity
        default:
            selectedType = .Flight
            
        }
    }
    
    @IBAction func startPlanningAction(_ sender: Any) {
        
        switch selectedType {
        case .Flight:
            self.performSegue(withIdentifier: "searchFlights", sender: nil)
            
        case .Hotel:
            self.performSegue(withIdentifier: "searchHotel", sender: nil)
            
        case .Activity:
            //self.performSegue(withIdentifier: "searchActivity", sender: nil)
            print("Navigate to activity")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
