//
//  SignUpViewController.swift
//  FIT3178_Final_App
//
//  Created by Jeet Ramchandani on 3/5/2023.
//

import UIKit
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore

class SignUpViewController: UIViewController {

    @IBOutlet weak var signUpOutlet: UIButton!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var firstNameTextField: UITextField!
    
    var activityIndicatorView = UIActivityIndicatorView(style: .large)
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    func createUser(){
        self.signUpOutlet.isUserInteractionEnabled = false
        if let email = emailTextField.text , let password = passwordTextField.text , let firstName = firstNameTextField.text , let lastName = lastNameTextField.text {
            showIndicator(activityIndicatorView: activityIndicatorView)
            Auth.auth().createUser(withEmail: email, password: password) { authResult,error in
                print(authResult)
                print(error)
                self.signUpOutlet.isUserInteractionEnabled = true
                self.hideIndicator(activityIndicatorView: self.activityIndicatorView)
                if error != nil {
                    self.displayAlert(message: "Sign Up Failed")
                }
                else{
                    
                    let db = Firestore.firestore()
                    var reference: DocumentReference?
                    reference = db.collection( "users").addDocument(data: ["first": firstName , "last": lastName])
                    self.navigationController?.popViewController(animated: true)
                }
            }
            
            
        } else{
            self.signUpOutlet.isUserInteractionEnabled = true
        }
        
    }
    
    func validateinputs() -> Bool {
        
        guard let firstName = firstNameTextField.text, !firstName.isEmpty, let lastName = lastNameTextField.text,!lastName.isEmpty , let email = emailTextField.text, !email.isEmpty,  let password = passwordTextField.text , !password.isEmpty, let confirmPassword = confirmPasswordTextField.text ,!confirmPassword.isEmpty else {
           displayAlert(message: "Please fill all the fields")
            return false
        }
        guard isValidEmail(text: email) else {
            displayAlert(message: "Please eneter a valid email")
            return false
        }
        guard isValidPassword(pwd: password, cPwd: confirmPassword) else{
            return false
        }
        
        
        return true
    }
    
    func isValidEmail(text: String) -> Bool {
        
        let regex = try? NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
        let result = regex?.firstMatch(in: text, range: NSMakeRange(0, text.count))             // nsmakerange : from bigning to end
        
        
        return result != nil
    }
    
    func isValidPassword(pwd: String , cPwd: String) -> Bool {
        if pwd.count >= 6 {
            if pwd == cPwd {
                return true
                
            }
            else{
                displayAlert(message: "Please make sure the password matches with the confirmPassword field")
            }
        }
        else {
            displayAlert(message: "Please eneter a valid password")
        }
        return false
    }
    

     @IBAction func signUpActionButton(_ sender: Any) {
         if validateinputs() {
             createUser()
             
         }
     }

}
