//
//  UIViewController+Extension.swift
//  FIT3178_Final_App
//
//  Created by Guest User on 4/5/2023.
//

import Foundation
import UIKit
extension UIViewController {
    func displayAlert(message: String){
    let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
    let okAction = UIAlertAction(title: "Okay", style: .default)
    alertController.addAction(okAction) // add teh button to the controller
    self.present(alertController, animated: true) // displaying the alert controller
    
}
    
    func showIndicator(activityIndicatorView: UIActivityIndicatorView){
        activityIndicatorView.center = self.view.center
        activityIndicatorView.startAnimating()
        self.view.addSubview(activityIndicatorView)
    }
    
    func hideIndicator(activityIndicatorView: UIActivityIndicatorView){
        activityIndicatorView.stopAnimating()
        activityIndicatorView.removeFromSuperview()
        
    }
}

